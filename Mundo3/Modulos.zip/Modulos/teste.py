from uteis import numeros
numero = int(input('Insira o valor : '))
fat = numeros.fatorial(numero)
print(f'O fatorial de {numero} é {fat}')